# MultiModulesDemo
Demo of multiple modules per repo.

# current status:

- Started with single module at top level.
- Duplicated files into mod1 directory
- Deleted original files at top level
- Created new package.json with sub-module listing.
