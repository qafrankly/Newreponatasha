import React, { Component, PropTypes } from 'react';

class MultiDemo14 extends Component {
	
  render(){
	  
    return (
      <div className='FranklyFourthModulesDemo'>
	      <h2 className='demo_text'>nad4: {this.props.text}</h2>
      </div>
    );
	  
  }
}

export default MultiDemo14;
