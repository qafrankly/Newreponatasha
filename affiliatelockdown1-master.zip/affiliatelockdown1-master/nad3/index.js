import React, { Component, PropTypes } from 'react';

class MultiDemo13 extends Component {
	
  render(){
	  
    return (
      <div className='FranklyThirdModulesDemo'>
	      <h2 className='demo_text'>nad3: {this.props.text}</h2>
      </div>
    );
	  
  }
}

export default MultiDemo13;
