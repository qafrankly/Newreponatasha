import React, { Component, PropTypes } from 'react';

class MultiDemo12 extends Component {
	
  render(){
	  
    return (
      <div className='FranklySecondModulesDemo'>
	      <h2 className='demo_text'>nad2: {this.props.text}</h2>
      </div>
    );
	  
  }
}

export default MultiDemo12;
