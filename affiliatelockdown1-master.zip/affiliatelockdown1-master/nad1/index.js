import React, { Component, PropTypes } from 'react';

class MultiDemo11 extends Component {
	
  render(){
	  
    return (
      <div className='FranklyModulesDemo'>
	      <h2 className='demo_text'>nad1: {this.props.text}</h2>
      </div>
    );
	  
  }
}

export default MultiDemo11;
